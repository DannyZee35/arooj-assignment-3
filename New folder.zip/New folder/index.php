
<?php
session_start();
?>
 
 <?php
if($_SESSION["name"]) {
?>





<?php
}else echo "<h1>Please login first .</h1>";
?>
<style><?php include 'C:\Users\user1\Desktop\arooj\style.css'; ?></style>
 
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
     <title>Document</title>

</head>
<style>
a{
    text-decoration:"none";
}

</style>

<body>
    <header class="header">
        <nav class="navbar">
            <div>
            <?php echo $_SESSION["name"]; ?>
            </div>
            <ul>
                <li>
                    Home
                </li>
                <li>
                    About
                </li>
                <li>
                <a style="text-decoration: none; color: black;"   href="logout.php" tite="Logout">Logout

                </li>
            </ul>
            <button class="btn" >
                Contact
            </button>  

        </nav>
    </header>

    <!-- Hero section -->
    <div class="hero">
        <div class="overlay"></div>
        <div class="hero-container">
            <h1 class="heading">TRY OUT OUR LATEST PRODUCTS </h1>
            <h1 class="heading">Sale 2022</h1>
            <button class="btn">
                Shop Now
            </button>

        </div>
    </div>

    <!-- Products section -->
    <div class="top-products">

        <div class="products-container">
            <h1 class="heading">Featured Products </h1>

            <div class="card-container">
                <div class="card">
                    <img src="orange.webp" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Orange Bag</h4>
                        <p>$100</p>
                    </div>
                </div>
                <div class="card">
                    <img src="yellow.jpg" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Yellow Bag</h4>
                        <p>$200</p>
                    </div>
                </div>
                <div class="card">
                    <img src="black.jpg" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Black Bag</h4>
                        <p>$400</p>
                    </div>
                </div>
                <div class="card">
                    <img src="red.jpg" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Red Bag</h4>
                        <p>$500</p>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- About  Us section -->
    <div class="about">

        <div class="about-container">
            <h1 class="heading">About Us</h1>

        </div>
        <div class="flex-container">
            <img src="about.jpg" alt="Avatar" style="width:500px;height: 500px;">
            <div>
                <p class="para">
                    We are a company which deals in ladies bags and other related products. We are an ecommerce business
                    also with multiple shops
                    in different areas of Pakistan. We provide quality products with full gurantee. Our business was
                    first founded in 2010 and since
                    then we have become one of the top selling ecommerce brand in Pakistan.
                </p>
                <button class="btn">Read More</button>
            </div>

        </div>
    </div>

    <!--Service section -->
    <div class="about">

        <div class="service-container">
            <h1 class="heading">Our Services</h1>

        </div>
        <div class="flex-container">
            <div class="service-card">
                <div class="container2">
                    <h4>Free Home Delivery</h4>
                    <p>We provide free home delivery with purchase.</p>
                    <button class="btn2">Read More</button>
                </div>
            </div>
            <div class="service-card">
                <div class="container2">
                    <h4>30 days return service</h4>
                    <p>You can return the product if you dont like it within 30 days</p>
                    <button class="btn2">Read More</button>
                </div>
            </div>
            <div class="service-card">
                <div class="container2">
                    <h4>Money Back Gurantee</h4>
                    <p>We provide full refund in case of any issue.</p>
                    <button class="btn2">Read More</button>
                </div>
            </div>

        </div>
    </div>

    
    <!-- Featured Products section -->
    <div class="top-products">

        <div class="products-container">
            <h1 class="heading">Featured Products </h1>

            <div class="card-container">
                <div class="card">
                    <img src="purse.webp" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Purse</h4>
                        <p>$250</p>
                    </div>
                </div>
                <div class="card">
                    <img src="show1.jpg"Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Shows</h4>
                        <p>$200</p>
                    </div>
                </div>
                <div class="card">
                    <img src="neck.jpg" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Necklace</h4>
                        <p>$350</p>
                    </div>
                </div>
                <div class="card">
                    <img src="dress.jpg" alt="Avatar" style="width:300px;height: 300px;">
                    <div class="container">
                        <h4>Dress</h4>
                        <p>$500</p>
                    </div>
                </div>
            </div>

        </div>
    </div>

        <!-- Newsletter section -->
        <div class="news">
            <div class="news-container">
                <h1>Subscribe to out newsletter</h1>
                <p>You can subscribe to our newsletter if you want latest news and updates from us.</p>
                <button class="btn3">Subscribe</button>
            </div>
        </div>

          <!-- Footer section -->
    <footer class="footer">
        <h1>copyright@2022</h1>
    </footer>
</body>
</html>
